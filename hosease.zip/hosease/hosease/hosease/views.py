from django.shortcuts import render,redirect
from django.http import HttpResponse,HttpResponseRedirect
from service.models import Service


def doctors(request):
    return render(request, 'doctors.html')

def find(request):
    obj = Service.objects.filter(city=request.GET.get('output'))
    
    
    
    
    if obj.exists():

         return render(request, 'find.html', {'obj': obj})
    else:
        return HttpResponse("No data found")
   
    
def home(request):
     
     try:
      


       if request.method == 'POST':
         obj = request.POST.get('location')
         if obj!= "":
             url='/find/?output={}'.format(obj)
             return HttpResponseRedirect(url)
             
            
         
     except:
            pass
     return render(request, 'home.html')
     
     
  
