from django.db import models

class Service(models.Model):
    name= models.CharField(max_length=100)
    services= models.CharField(max_length=100)
    rating=models.FloatField()
    phone_number=models.CharField(max_length=15)
    city=models.CharField(max_length=100)
    
# Create your models here.
